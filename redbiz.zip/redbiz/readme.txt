I. Theme

FO, Copyright 2017
FO is licensed under GNU General Public License V2 or later. You can find a copy of it in the license.txt file.

II. Resources

1. Bootstrap
Location /css/bootstrap.min.css file is from the Bootstrap v3.3.5 (http://getbootstrap.com) package.
Resource URI: http://getbootstrap.com/
Copyright: 2011-2014 Twitter, Inc
License: MIT
License URI: http://opensource.org/licenses/MIT

2. Icons
The icon set used in FO is FontAwesome.
Copyright: Dave Gandy
Resource URI: http://fontawesome.io
License: SIL Open Font License, Version 1.1
License URI: https://scripts.sil.org/OFL?

The icon set used in FO is Linecons.
Copyright: Designmodo
Resource URI:
http://designmodo.com/linecons-free/
http://www.fontello.com/
License: SIL Open Font License, Version 1.1
License URI: https://scripts.sil.org/OFL?

3. FitVids
Copyright: Chris Coyier, Paravel
Resource URI: http://fitvidsjs.com/
License: WTFPL
License URI: http://www.wtfpl.net/txt/copying/

4. jQuery Waypoints
Copyright: 2011-2014 Caleb Troughton
Resource URI: http://imakewebthings.com/jquery-waypoints/
License: MIT
License URI: http://opensource.org/licenses/MIT

5. OwlCarousel
Copyright: 2013 Bartosz Wojciechowski
Resource URI: http://www.owlgraphic.com/owlcarousel/
License: MIT
License URI: http://opensource.org/licenses/MIT

6. jQuery Isotope
Copyright: Matt Huggins
Resource URI: http://isotope.metafizzy.co
License: MIT
License URI: http://isotope.metafizzy.co

7. jQuery Parallax
Copyright: Ian Lunn
Resource URI: http://www.ianlunn.co.uk/plugins/jquery-parallax/
License: MIT/GPL
License URI: http://opensource.org/licenses/MIT
License URI: http://www.gnu.org/licenses/gpl-2.0.html

8. jQuery Respond
Copyright: Scott Jehl
Resource URI: https://github.com/scottjehl/Respond
License: MIT
License URI: http://opensource.org/licenses/MIT
License URI: http://www.gnu.org/licenses/gpl-2.0.html

III. Documentation 

Theme documentation is available on 